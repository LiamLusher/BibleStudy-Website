# Bible Study Launch Page

This is a single-file static landing page for Bible Study V1.0.0.

## Quick publish with GitHub Pages
1. Create a new GitHub repository, for example `BibleStudy-Website`.
2. Upload `index.html` to the root of the repository.
3. In GitHub: Settings -> Pages.
4. Under Build and deployment, choose `Deploy from a branch`.
5. Select `main` and `/ (root)`, then Save.
6. GitHub will give you a public website URL.

The Download buttons already point to the official V1.0.0 Windows installer.
